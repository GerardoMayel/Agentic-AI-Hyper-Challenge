# rxconfig.py - Configuración simplificada para export estático
import reflex as rx
import os

# Configuración simplificada para export estático
config = rx.Config(
    app_name="app",
    db_url=None,  # Sin base de datos para export estático
    api_url="http://localhost:8000",  # URL dummy
    cors_allowed_origins=["*"],
    loglevel="info",
    # Tailwind configuration
    tailwind={
        "theme": {
            "extend": {
                "colors": {
                    "zurich": {
                        "blue": "#0066CC",
                        "dark-blue": "#004499",
                        "light-blue": "#E6F3FF",
                        "gray": "#666666",
                        "light-gray": "#F5F5F5"
                    }
                }
            }
        }
    },
    plugins=[]
) 